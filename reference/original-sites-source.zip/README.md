# Olson & Tenglund, Inc.

Automotive parts storefront and private inventory workspace for Olson & Tenglund, Inc., with stores in Coudersport, Port Allegany and Smethport, Pennsylvania. The application uses Vinext/React on a Cloudflare Worker, with Cloudflare D1 for persistent business records.

**The catalog starts empty.** No real inventory, suppliers, prices, stock counts or vehicle applications have been supplied or seeded. Staff can create records or prepare CSV imports as that information becomes available.

## Access boundary

Keep this Site **private**. The current access boundary is the Site's private sharing policy: every visitor admitted to the private Site is treated as an authorized staff member. The application does not yet have a separate staff allowlist, employee roles or customer authorization model.

**Implement and test server-side staff authorization before changing the Site to public.** Protect `/admin` and every `/api/admin/*` endpoint independently of the storefront. A signed-in identity alone must not grant permission to manage business records on a public Site.

Shop accounts are internal business records and price-list assignments. They do not create customer logins, customer portals, credit approvals or payment accounts.

## Available workflows

| Surface | Purpose |
| --- | --- |
| `/admin` | Staff overview, setup checklist, record management and recent activity |
| `/admin#products` | Product identities, sources, draft status and publication review |
| `/admin#imports` | CSV templates, upload/paste, mapping, validation and import history |
| `/admin#stock` | SKU/location balances and recorded stock adjustments |
| `/` | Customer-facing storefront using published catalog data |

The console manages ten record types: **products, part specifications, selling SKUs, vehicle configurations, fitment applications, suppliers, supplier offers, locations, prices and business accounts**. It includes search, pagination, create/edit forms, reference lookups and optimistic revision checks. Stable keys cannot be renamed after creation.

`opening_stock` is an additional **import-only** type. It records opening counts through the stock workflow; it is not a separate editable count table.

### Product and quantity model

- A product represents the branded part. Keep its part brand and manufacturer part number distinct from a vehicle make or supplier ordering number.
- A selling SKU represents a unit or package sold for that product. Several packaging SKUs can refer to one product.
- Each product defines a canonical base unit. `base_units_per_selling_unit` converts one SKU selling unit into product base units; fitment quantities use that product base unit.
- Stock movements, balances, reorder points and prices use the SKU's selling unit. Do not count the same goods once as cases and again as individual units.
- Specifications belong to the product. Vehicle applications are separate relationships; another application does not create another stock balance.
- Supplier availability is dated sourcing information and never increases local stock automatically.

Money is stored in integer cents and quantity values in integer thousandths. Excess decimal precision is rejected rather than silently rounded.

## First-use sequence

Start with a small set of real, well-documented parts and complete their connected records before importing a large catalog.

| Create first | Then add |
| --- | --- |
| Products | Selling SKUs and product specifications |
| Selling SKUs | Retail, trade or named-list prices |
| Products and vehicle configurations | Fitment applications |
| Suppliers and selling SKUs | Supplier offers |
| Selling SKUs and locations | Opening stock counts |
| Consistent price-list keys | Business-account price-list assignments |

For a manual start, save a product draft, create its SKU, add specifications and pricing, then enter a location and opening stock. Add vehicle applications from supported source information. Unknown details and unresolved restrictions remain unknown; missing fields do not imply unrestricted fitment.

New and imported products remain drafts. Open an existing product to review its readiness issues. After addressing them, explicitly choose storefront visibility and save. The server checks publication prerequisites.

### Stock controls

Use **Stock & locations → Adjust stock** to add or remove a quantity, select its disposition and record a reason. For opening stock, add the counted quantity once. For a later correction, enter the difference being added or removed, not the new total.

Sellable, damaged, quarantine and core quantities remain separate. Opening-stock imports accept only positions with no existing stock history; they cannot overwrite live balances. Keep the count key and reason for traceability. Counts are not order reservations.

The stock page defaults to **All locations**. Choosing a location filters its rows, total count, summary and pagination together. Products and selling SKUs are shared across the three stores; each store keeps separate stock balances. A store with no recorded stock is not assumed to have another store’s quantity.

Location records include optional street address, city, state, ZIP code, phone and store hours. Confirm these details before filling them in. Active store records expose their contact information on the storefront; internal location notes remain staff-only. The admin form separates location basics, store contact/hours and internal notes. No code automatically creates or duplicates store records.

## CSV imports

1. Select a record type and download its blank CSV template.
2. Add real records. Preserve keys, barcodes and part numbers as text, then export UTF-8 CSV with one header row.
3. Upload or paste the CSV and match source columns to destination fields.
4. Validate on the server. Review normalized records and row errors; download the error CSV when corrections are needed.
5. Explicitly apply a valid batch. The server uses its saved staging data and revalidates against current records.

Import rules:

- **CSV only, maximum 250 data rows per batch.** The upload limit is 2 MB; the parser also bounds text size. XLSX, ACES and PIES files are not accepted by this generic importer.
- Imports are **create-only**. Existing keys and duplicates produce errors, not implicit updates.
- The whole batch must be valid. Application is atomic, with no silent partial import.
- Dependencies must already exist. Import products before SKUs, and SKUs/locations before opening counts.
- Products import as drafts. Imported vehicle configurations and applications still need their respective reviews.
- History records staged and applied batches. Error CSV downloads escape spreadsheet-formula prefixes; source values remain available for validation.

## Storefront behavior and limits

The storefront reads published catalog records through `/api/catalog`. Draft products and an empty catalog do not become sample inventory. Vehicle matching depends on the actual records supplied and reviewed by staff.

The browser cart is an **order list**. Quantity controls, copy/download actions and job references do not submit an order, reserve stock, process payments or promise fulfillment. Shop inquiries prepare local drafts; they do not create customer logins or automatically send an application.

The visual direction and retained thematic imagery are design assets, not actual-stock evidence or photographs of the premises. Confirm approved branding, contact details, photography, policies and fulfillment terms before a public launch. No current supplier affiliation is assumed.

## Implementation map

| Path | Responsibility |
| --- | --- |
| `app/admin/` | Staff console, metadata-driven forms and CSV wizard |
| `app/api/admin/` | Bootstrap, record, stock and import endpoints |
| `app/api/catalog/` | Storefront catalog endpoint |
| `app/api/locations/` | Public contact information for active store locations |
| `lib/inventory/entities.ts` | Entity definitions, keys, field metadata and import-only types |
| `lib/inventory/validation.ts` | Normalization, validation and quantity/money precision |
| `lib/inventory/` | Inventory services and shared CSV utilities |
| `db/schema.ts`, `db/index.ts` | Runtime Drizzle SQLite/D1 schema and binding access |
| `drizzle/` | Generated SQL migrations, snapshots and journal |
| `app/route.ts`, `public/storefront/` | Retained storefront HTML, JavaScript, styles and assets |
| `worker/index.ts`, `vite.config.ts` | Worker entrypoint and Vinext/Sites integration |
| `.openai/hosting.json` | Site identity and logical D1 binding `DB` |

The earlier `olson-tenglund-catalog-schema.sql` PostgreSQL design and inventory workbook are reference artifacts. **The PostgreSQL file is not the running schema and has not been executed as an application migration.** This application uses D1/SQLite and tracked Drizzle migrations. Workbook columns require explicit mapping to runtime import templates; the workbook is not a connected ledger.

## Development and migrations

Use Node.js 22.13 or later. Run commands from the project root. With the Sites plugin, replace `<sites-plugin-root>` with its installed directory and use its lifecycle helpers:

```sh
node <sites-plugin-root>/scripts/install-dependencies.mjs
node <sites-plugin-root>/scripts/build-site.mjs
```

Do not overlap installers. `npm run dev` and `npm run build` remain available for standalone development. In the managed Sites workspace, use `sites-preview start <absolute-checkout-path>` for browser QA and open the exact returned URL; do not launch a second preview server.

For schema changes, edit `db/schema.ts`, generate a new migration and inspect its SQL:

```sh
npm run db:generate
```

Build once to produce `dist/server/wrangler.json`. Apply each pending migration locally, in order, replacing the example filename:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/NNNN_migration_name.sql
```

Local preview data and hosted D1 data are separate. Do not replay applied migrations, edit applied SQL, rewrite snapshots or alter the journal's history. Append migrations for subsequent changes. Keep migrations free of business seed data. Hosted migrations and publication belong to the Sites deployment workflow; local migration does not publish or change hosted data.

## Checks

```sh
./node_modules/.bin/tsc --noEmit --pretty false
node --test tests/inventory-csv.test.mjs
node scripts/test-inventory.mjs
```

The CSV tests cover quoting, multiline values, BOM/header handling, row limits, mappings and spreadsheet-safe exports. The API integration runner requires Node 24 and executes the actual route handlers against a fresh in-memory SQLite database loaded from the generated migrations. Its 17 groups cover identity, validation, stock and import transactions, public data projection, vehicle facets, fitment restrictions, and same-origin writes. It starts no server and disables network fetch. These are API/SQLite checks, not production Cloudflare D1 or browser tests; see `tests/README.md` for the boundary. Run the full build and verify the managed preview before releasing database or workflow changes.

## Remaining work for public ecommerce

- Supply and verify real catalog, supplier, pricing, vehicle, fitment and stock data, with permission to use the content and images.
- Add supplier-specific CSV mappings and ACES/PIES adapters, including licensed reference data where required.
- Connect POS/inventory synchronization and maintained supplier feeds.
- Implement explicit staff authorization, customer authentication and account-specific access rules.
- Build server-side checkout, orders, atomic reservations, payments, taxes and fulfillment.
- Define and implement the core-return/credit workflow, returns rules and approved store policies.
