#!/usr/bin/env node
/**
 * API/SQLite integration tests. No server listeners, network, D1 credentials,
 * production writes, or browser automation. Run: node scripts/test-inventory.mjs
 */
import assert from 'node:assert/strict';
import { mkdir, readdir, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';
import { SqliteD1 } from '../tests/sqlite-d1.mjs';
import { runInventoryIntegration } from '../tests/inventory-integration.mjs';

const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = resolve(project, 'outputs/tests');
await mkdir(outputDirectory, { recursive: true });
const bundle = resolve(outputDirectory, 'inventory-routes.mjs');
await build({
  absWorkingDir: project,
  entryPoints: [resolve(project, 'tests/inventory-routes.ts')],
  outfile: bundle,
  bundle: true,
  platform: 'node',
  target: 'node24',
  format: 'esm',
  tsconfig: resolve(project, 'tsconfig.json'),
  logLevel: 'warning',
  plugins: [{
    name: 'test-only-cloudflare-env',
    setup(builder) {
      builder.onResolve({ filter: /^cloudflare:workers$/ }, () => ({ path: 'cloudflare-test-env', namespace: 'test-only-env' }));
      builder.onLoad({ filter: /.*/, namespace: 'test-only-env' }, () => ({ contents: 'export const env = {};', loader: 'js' }));
    },
  }],
});

const db = new SqliteD1();
const originalFetch = globalThis.fetch;
let blockedNetworkRequests = 0;
globalThis.fetch = async () => {
  blockedNetworkRequests += 1;
  throw new Error('Network fetch is disabled in the in-memory API integration runner.');
};
try {
  const migrationFiles = (await readdir(resolve(project, 'drizzle'))).filter((name) => name.endsWith('.sql')).sort();
  assert.ok(migrationFiles.length, 'At least one actual generated migration is required.');
  for (const file of migrationFiles) db.sqlite.exec(await readFile(resolve(project, 'drizzle', file), 'utf8'));
  console.log(`Applied ${migrationFiles.length} actual generated migration(s) to fresh in-memory SQLite.`);
  const { setTestDatabase, testFetch } = await import(pathToFileURL(bundle).href + '?run=' + Date.now());
  setTestDatabase(db);
  const origin = 'http://127.0.0.1:4173';
  const base = await runInventoryIntegration({ testFetch, origin, environment: 'in-memory-sqlite' });
  let additionalPassed = 0;
  async function request(path, body, method = body ? 'POST' : 'GET') {
    const response = await testFetch(origin + path, { method, headers: { Origin: origin, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
    return { status: response.status, ok: response.ok, data: await response.json() };
  }
  async function good(path, body, method) { const result = await request(path, body, method); assert.ok(result.ok, JSON.stringify(result)); return result.data; }
  async function preview(entity, records) {
    const headers = [...new Set(records.flatMap(Object.keys))];
    const rows = records.map((row) => Object.fromEntries(headers.map((header) => [header, String(row[header] ?? '')])));
    const result = await good('/api/admin/imports/preview', { entity, filename: 'TEST-ONLY-atomic-rollback.csv', rows, mapping: Object.fromEntries(headers.map((header) => [header, header])) });
    assert.equal(result.errorCount, 0);
    return result;
  }

  const sku = base.prefix + '-S';
  const priceList = base.prefix + '-RACE';
  const priceOne = base.prefix + '-ATOMICPRICE1';
  const priceTwo = base.prefix + '-ATOMICPRICE2';
  const stagePrice = await preview('prices', [
    { price_key: priceOne, internal_sku: sku, price_list: priceList, minimum_quantity: 1, unit_price: '10.00', core_charge: 0 },
    { price_key: priceTwo, internal_sku: sku, price_list: priceList, minimum_quantity: 2, unit_price: '9.00', core_charge: 0 },
  ]);
  db.beforeNextBatch((sqlite) => {
    const stamp = new Date().toISOString();
    sqlite.prepare('INSERT INTO inv_prices (price_key,price_list,internal_sku,minimum_quantity_milli,unit_price_cents,core_charge_cents,status,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?,1,?,?)')
      .run(base.prefix + '-RACECONFLICT', priceList, sku, 2000, 800, 0, 'active', stamp, stamp);
  });
  const priceResult = await request('/api/admin/imports/apply', { id: stagePrice.id });
  assert.equal(priceResult.status, 409, JSON.stringify(priceResult));
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS count FROM inv_prices WHERE price_key IN (?,?)').get(priceOne, priceTwo).count, 0, 'No earlier row in a conflicted price batch may survive.');
  assert.equal(db.sqlite.prepare('SELECT status FROM inv_import_batches WHERE id=?').get(stagePrice.id).status, 'preview');
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS count FROM inv_audit_log WHERE record_key=? AND action=?').get(stagePrice.id, 'import_apply').count, 0);
  additionalPassed += 1;
  console.log('PASS real SQLite rollback of a price import after a concurrent conflict causes a guarded insert to skip');

  const location = base.prefix + '-ATOMICLOCATION';
  await good('/api/admin/records', { entity: 'locations', record: { location_key: location, name: 'TEST ONLY atomic opening bin', type: 'bin' } });
  const stageStock = await preview('opening_stock', [
    { count_key: base.prefix + '-ATOMICOPEN1', internal_sku: sku, location_key: location, disposition: 'sellable', quantity: 7, reason: 'TEST ONLY opening' },
    { count_key: base.prefix + '-ATOMICOPEN2', internal_sku: sku, location_key: location, disposition: 'quarantine', quantity: 2, reason: 'TEST ONLY opening' },
  ]);
  db.beforeNextBatch((sqlite) => {
    sqlite.prepare('INSERT INTO inv_stock_events (id,idempotency_key,internal_sku,location_key,event_type,opening_position_key,quantity_milli,disposition,reason,actor,created_at) VALUES (?,?,?,?,?,NULL,?,?,?,?,?)')
      .run(crypto.randomUUID(), base.prefix + '-RACESTOCK', sku, location, 'adjustment', 1000, 'quarantine', 'TEST ONLY competing committed adjustment', 'test-adapter', new Date().toISOString());
  });
  const stockResult = await request('/api/admin/imports/apply', { id: stageStock.id });
  assert.equal(stockResult.status, 409, JSON.stringify(stockResult));
  assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS count FROM inv_stock_events WHERE location_key=? AND event_type='opening'").get(location).count, 0, 'No earlier opening count may survive a conflicted batch.');
  const finalBalance = db.sqlite.prepare('SELECT SUM(quantity_milli) AS balance FROM inv_stock_events WHERE location_key=?').get(location).balance;
  assert.equal(finalBalance, 1000, 'Only the independently committed adjustment remains.');
  assert.equal(db.sqlite.prepare('SELECT status FROM inv_import_batches WHERE id=?').get(stageStock.id).status, 'preview');
  additionalPassed += 1;
  console.log('PASS real SQLite rollback of an opening-stock import after position history appears concurrently');

  assert.equal(db.nextBatchHook, null, 'Every race hook must actually have executed.');
  assert.ok(db.rollbackCount >= 2, 'Both guarded-import tests must have caused real transactional rollbacks.');
  assert.equal(blockedNetworkRequests, 0, 'The actual handlers must not attempt network requests in this suite.');
  console.log(JSON.stringify({ passed: base.passed + additionalPassed, baseGroups: base.passed, atomicRaceGroups: additionalPassed, sqliteTransactions: db.batchCount, sqliteRollbacks: db.rollbackCount, environment: 'actual-api-handlers-with-in-memory-sqlite', productionD1Tested: false, browserTested: false, networkRequests: 0 }));
} finally {
  globalThis.fetch = originalFetch;
  db.close();
}
