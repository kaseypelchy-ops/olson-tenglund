/** Test-only D1-shaped adapter. Executes real SQLite; does not contact D1. */
import { DatabaseSync } from 'node:sqlite';

class Statement {
  constructor(database, sql, parameters = []) {
    this.database = database;
    this.sql = sql;
    this.parameters = parameters;
  }
  bind(...parameters) { return new Statement(this.database, this.sql, parameters); }
  execute() {
    const statement = this.database.sqlite.prepare(this.sql);
    const results = statement.all(...this.parameters);
    const meta = this.database.sqlite.prepare('SELECT changes() AS changes, last_insert_rowid() AS last_row_id').get();
    return { success: true, results, meta: { changes: Number(meta.changes), last_row_id: Number(meta.last_row_id), duration: 0, rows_read: results.length, rows_written: Number(meta.changes), changed_db: Number(meta.changes) > 0 } };
  }
  async all() { return this.execute(); }
  async run() { return this.execute(); }
  async first(columnName) {
    const row = this.database.sqlite.prepare(this.sql).get(...this.parameters);
    if (!row) return null;
    if (columnName !== undefined) return row[columnName] ?? null;
    return row;
  }
}

export class SqliteD1 {
  constructor() {
    this.sqlite = new DatabaseSync(':memory:');
    this.sqlite.exec('PRAGMA foreign_keys = ON;');
    this.nextBatchHook = null;
    this.batchCount = 0;
    this.rollbackCount = 0;
  }
  prepare(sql) { return new Statement(this, sql); }
  beforeNextBatch(callback) {
    if (this.nextBatchHook) throw new Error('A batch hook is already pending.');
    this.nextBatchHook = callback;
  }
  async batch(statements) {
    // A one-shot hook simulates an independently committed write arriving
    // after application revalidation but before its transaction begins.
    const hook = this.nextBatchHook;
    this.nextBatchHook = null;
    if (hook) hook(this.sqlite);
    this.batchCount += 1;
    this.sqlite.exec('BEGIN IMMEDIATE');
    try {
      const results = statements.map((statement) => {
        if (!(statement instanceof Statement) || statement.database !== this) throw new TypeError('A batch must contain statements prepared by this database.');
        return statement.execute();
      });
      this.sqlite.exec('COMMIT');
      return results;
    } catch (error) {
      this.sqlite.exec('ROLLBACK');
      this.rollbackCount += 1;
      throw error;
    }
  }
  close() { this.sqlite.close(); }
}
