# Inventory checks

Run the pure CSV parsing and export checks:

```sh
node --test tests/inventory-csv.test.mjs
```

Run the API and database checks with Node 24:

```sh
node scripts/test-inventory.mjs
```

The API runner bundles the actual route handlers with the installed esbuild,
replacing only `cloudflare:workers` with a test environment containing the
database adapter. It applies every generated `drizzle/*.sql` migration to a
fresh in-memory SQLite database. Requests are dispatched to the actual route
functions; there is no HTTP listener. Global network fetch is disabled for the
run. The generated test bundle is saved under ignored `outputs/tests`.

The 16 main groups cover part-number identity, draft defaults, duplicates,
foreign keys, publication prerequisites, exact money, price overlap, opening
counts, stock balance floors, retry idempotency, unit changes, revision
conflicts, public field projection, invalid and duplicate imports, incomplete
fitment, cascading vehicle facets, store-specific availability, and same-origin write checks. The vehicle
group follows a reviewed configuration through year, make, model, configuration,
and catalog lookup; partial applications are excluded, and restricted fits
cannot become confirmed picker options. The store group checks selected-store
counts, recorded zero versus unknown, exclusion of warehouses and archived
stores from customer availability, private notes, and filtered stock totals.
Two additional groups introduce a
competing committed price or stock event after validation and before import
application. They execute real SQLite transactions and verify that a later
conflict rolls back every earlier row in that import batch.

These are API and SQLite integration checks, not production Cloudflare D1 or
browser tests. The small adapter implements only the D1 operations used by
these routes. Its deterministic conflict hooks check relevant SQL
interleavings; they do not simulate distributed database concurrency,
Cloudflare authorization, deployment configuration, or browser behavior.

`tests/inventory-integration.mjs` also retains its original standalone HTTP
mode for an explicitly selected disposable loopback development database.
That mode creates labeled QA records and rejects non-loopback origins. The
in-memory runner above requires no preview server and leaves no inventory
records behind.
