import { adminHandler, publicCatalog } from "@/lib/inventory/server";
export async function GET(request: Request) { return adminHandler(request, () => publicCatalog(request)); }
