import { adminHandler, publicVehicles } from "@/lib/inventory/server";
export const dynamic = "force-dynamic";
export async function GET(request: Request) { return adminHandler(request, () => publicVehicles(request)); }
