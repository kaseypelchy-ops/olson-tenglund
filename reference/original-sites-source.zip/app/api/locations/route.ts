import { adminHandler, publicLocations } from "@/lib/inventory/server";
export async function GET(request: Request) { return adminHandler(request, () => publicLocations()); }
