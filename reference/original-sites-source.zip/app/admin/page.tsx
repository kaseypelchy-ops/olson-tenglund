import type { Metadata } from "next";
import InventoryWorkspace from "./inventory-workspace";
import "./admin.css";

export const metadata: Metadata = {
  title: "Inventory Workspace | Olson & Tenglund, Inc.",
  description: "Manage the Olson & Tenglund parts catalog, vehicle applications, inventory and trade pricing.",
};

export default function AdminPage() {
  return <InventoryWorkspace />;
}
